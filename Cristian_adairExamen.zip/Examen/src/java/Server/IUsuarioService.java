/*
Autor= Cristian Adair Ramirez Rodriguez
Fecha creacion= 16/03/2022
Fecha actualizacion= 16/03/2022
Descripcion= Interface de usuario del paquete Service
 */
package server;

import entity.Usuario;
import java.util.List;

public interface IUsuarioService {

    public void crearRegisto(Usuario usuario);

    public void actualizarRegistro(Usuario usuario);

    public List<Usuario> obtenerRegistros();

    public Usuario obtenerRegistro(int idUsuario);

    public void eliminarResgistro(int idUsuario);
}
