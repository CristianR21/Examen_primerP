/*
Autor= Cristian Adair Ramirez Rodriguez
Fecha creacion= 16/03/2022
Fecha actualizacion= 16/03/2022
Descripcion= Clase de usuario del paquete Service
 */
package Server;

import entity.Usuario;
import model.IUsuarioModel;
import model.UsuarioModelimpl;
import java.util.List;

public class UsuarioServiceImpl implements IUsuarioService {
    
    IUsuarioModel modelo = new UsuarioModelimpl();
    
    @Override
    public void crearRegisto(Usuario usuario) {
        modelo.crearRegisto(usuario);
    }
    
    
    @Override
    public List<Usuario> obtenerRegistros() {
        return modelo.obtenerRegistros();
    }
    
    @Override
    public Usuario obtenerRegistro(int idUsuario) {
        return modelo.obtenerRegistro(idUsuario);
    }
    
    
}
