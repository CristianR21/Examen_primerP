/*
Autor= Cristian Adair Ramirez Rodriguez
Fecha creacion= 07/03/2022
Fecha actualizacion= 08/03/2022
Descripcion= Paquete de entity y clase usuario que hereda de persona
 */
package entity;

import java.util.ArrayList;
import java.util.List;

public class Usuario extends Persona {

    private String nombre;
    private String sexo;
    private int edad;

    public Usuario() {
    }

    public Usuario(String nombre, String sexo, Integer edad) {
        super(nombre, sexo, edad);
        this.nombre = nombre;
        this.sexo = sexo;
        this.edad = edad;
    }

    public Usuario( String nombre, String sexo, int edad) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String codigo) {
        this.nombre = nombre;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String nombre_usuario) {
        this.sexo = sexo;
    }

    @Override
    public String getEdad() {
        return edad;
    }

    public void setEdad(String contraseña) {
        this.edad = edad;
    }

    public static void main(String[] args) {
        Usuario a = new Usuario("Simon", "Hombre", 18);
        Usuario b = new Usuario("Lincon", "Mujer", 20);
        Usuario c = new Usuario("Chris", "Hombre", 22);

        List<Usuario> lista = new ArrayList<Usuario>();
        lista.add(a);
        lista.add(b);
        lista.add(c);
        for (Usuario i : lista) {
            System.out.println("Nombre: " + i.getNombre());
            System.out.println("Sexo: " + i.getSexo());
            System.out.println("Edad: " + i.getEdad());
            System.out.println("\n\n");
        }
    }

}
