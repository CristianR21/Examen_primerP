/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import entity.Usuario;
import bd.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author labso07
 */
public class UsuarioModelimpl {
    private Conexion conexion;
    private Connection connection;
    
    public void crearRegisto(Usuario usuario) {
        try {
            conexion = new Conexion();
            conexion.Conectar();
            connection = conexion.getConnection();
            String sql = "insert into usuario( nombre, sexo, edad) values(?,?,?);";
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, usuario.getNombre());
            st.setString(2, usuario.getSexo());
            st.setInt(3, usuario.getEdad());
            st.executeUpdate();
            conexion.Desconectar();
        } catch (Exception ex) {
            System.out.println("Error de crear registro= " + ex);
        }
    }
}
